package com.example.motormanagementcummins;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class ViewDetailsActivity extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private List<String> motorDetailsList;
    private ArrayAdapter<String> adapter;
    private ListView listViewMotorDetails;
    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_details);

        // Initialize Firebase Realtime Database reference
        databaseReference = FirebaseDatabase.getInstance().getReference().child("motorDetails");

        // Initialize list to store motor details
        motorDetailsList = new ArrayList<>();

        // Initialize adapter for ListView
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, motorDetailsList);

        listViewMotorDetails = findViewById(R.id.listViewMotorDetails);
        listViewMotorDetails.setAdapter(adapter);

        searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return false;
            }
        });

        // Read data from Firebase and update ListView
        readData();
    }

    private void readData() {
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    // Retrieve individual motor details
                    String motorID = snapshot.child("motorID").getValue(String.class);
                    String frame = snapshot.child("frame").getValue(String.class);
                    String voltage = snapshot.child("voltage").getValue(String.class);
                    String amp = snapshot.child("amp").getValue(String.class);
                    String rpm = snapshot.child("rpm").getValue(String.class);
                    String kw = snapshot.child("kw").getValue(String.class);
                    String hp = snapshot.child("hp").getValue(String.class);
                    String location = snapshot.child("location").getValue(String.class);

                    // Format motor details into a String
                    String motorDetails = "Motor ID: " + motorID + "\n" +
                            "Frame: " + frame + "\n" +
                            "Voltage: " + voltage + "\n" +
                            "Amp: " + amp + "\n" +
                            "RPM: " + rpm + "\n" +
                            "KW: " + kw + "\n" +
                            "HP: " + hp + "\n" +
                            "Location: " + location;

                    // Add motor details to the list
                    motorDetailsList.add(motorDetails);
                }
                // Notify adapter of data change
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle errors
            }
        });
    }

    private void filter(String query) {
        if (TextUtils.isEmpty(query)) {
            listViewMotorDetails.clearTextFilter();
        } else {
            adapter.getFilter().filter(query);
        }
    }
}
