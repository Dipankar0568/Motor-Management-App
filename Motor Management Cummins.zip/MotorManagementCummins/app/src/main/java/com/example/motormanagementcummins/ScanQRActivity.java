package com.example.motormanagementcummins;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.motormanagementcummins.R;

public class ScanQRActivity extends AppCompatActivity {

    private TextView qrCodeTextView;
    private ActivityResultLauncher<Intent> qrCodeLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_qractivity);

        // Initialize TextView
        qrCodeTextView = findViewById(R.id.qrCodeTextView);

        // Initialize QR code launcher
        qrCodeLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                // Retrieve the scanned content from the result
                String qrCodeContent = result.getData().getStringExtra("SCAN_RESULT");
                if (qrCodeContent != null) {
                    // Display the scanned content in the TextView
                    qrCodeTextView.setText(qrCodeContent);
                }
            } else {
                // Handle case where the user cancels the scan
                qrCodeTextView.setText("Scan cancelled");
            }
        });

        // Call method to start scanning QR code
        startScanningQRCode();
    }

    private void startScanningQRCode() {
        Intent intent = new Intent(this, com.journeyapps.barcodescanner.CaptureActivity.class);
        intent.setAction("com.google.zxing.client.android.SCAN");
        intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
        qrCodeLauncher.launch(intent);
    }
}
