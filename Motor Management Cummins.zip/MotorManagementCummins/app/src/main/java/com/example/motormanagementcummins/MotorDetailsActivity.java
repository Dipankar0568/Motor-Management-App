package com.example.motormanagementcummins;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;

public class MotorDetailsActivity<MotorDetails> extends AppCompatActivity {

    EditText editTextMotorID, editTextFrame, editTextVoltage, editTextAmp, editTextRPM, editTextKW, editTextHP, editTextLocation;
    Button buttonGenerateQR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motor_details);

        // Initialize views
        editTextMotorID = findViewById(R.id.editTextMotorID);
        editTextFrame = findViewById(R.id.editTextFrame);
        editTextVoltage = findViewById(R.id.editTextVoltage);
        editTextAmp = findViewById(R.id.editTextAmp);
        editTextRPM = findViewById(R.id.editTextRPM);
        editTextKW = findViewById(R.id.editTextKW);
        editTextHP = findViewById(R.id.editTextHP);
        editTextLocation = findViewById(R.id.editTextLocation);
        buttonGenerateQR = findViewById(R.id.buttonGenerateQR);

        // Set click listener for Generate QR Code button
        buttonGenerateQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateQRCode();
            }
        });
    }
    public static class MotorDetails {
        public String motorID;
        public String frame;
        public String voltage;
        public String amp;
        public String rpm;
        public String kw;
        public String hp;
        public String location;

        public MotorDetails() {
            // Default constructor required for calls to DataSnapshot.getValue(MotorDetails.class)
        }

        public MotorDetails(String motorID, String frame, String voltage, String amp, String rpm, String kw, String hp, String location) {
            this.motorID = motorID;
            this.frame = frame;
            this.voltage = voltage;
            this.amp = amp;
            this.rpm = rpm;
            this.kw = kw;
            this.hp = hp;
            this.location = location;
        }
    }


    private void generateQRCode() {
        // Retrieve input values
        String motorID = editTextMotorID.getText().toString().trim();
        String frame = editTextFrame.getText().toString().trim();
        String voltage = editTextVoltage.getText().toString().trim();
        String amp = editTextAmp.getText().toString().trim();
        String rpm = editTextRPM.getText().toString().trim();
        String kw = editTextKW.getText().toString().trim();
        String hp = editTextHP.getText().toString().trim();
        String location = editTextLocation.getText().toString().trim();

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("motorDetails");
        String id = databaseReference.push().getKey();
        MotorDetails motorDetails = (MotorDetails) new MotorDetailsActivity.MotorDetails(motorID, frame, voltage, amp, rpm, kw, hp, location);
        databaseReference.child(id).setValue(motorDetails);

        // Concatenate input values to form QR code content
        String qrCodeContent = "Motor ID: " + motorID + "\n" +
                "Frame: " + frame + "\n" +
                "Voltage: " + voltage + "\n" +
                "Amp: " + amp + "\n" +
                "RPM: " + rpm + "\n" +
                "KW: " + kw + "\n" +
                "HP: " + hp + "\n" +
                "Location: " + location;

        // Generate QR code bitmap
        try {
            BitMatrix bitMatrix = new MultiFormatWriter().encode(qrCodeContent, BarcodeFormat.QR_CODE, 200, 200);
            int width = bitMatrix.getWidth();
            int height = bitMatrix.getHeight();
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    bitmap.setPixel(x, y, bitMatrix.get(x, y) ? getResources().getColor(R.color.black) : getResources().getColor(R.color.white));
                }
            }

            // Start QRDisplayActivity to display the generated QR code
            Intent intent = new Intent(MotorDetailsActivity.this, QRDisplayActivity.class);
            intent.putExtra("qrCodeBitmap", bitmap);
            startActivity(intent);
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }
}
